package com.cognizant.ormlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
